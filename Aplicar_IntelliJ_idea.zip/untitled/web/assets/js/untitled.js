function showpasswindow(){
    getElementById("change-pass").style.display = "default";
}