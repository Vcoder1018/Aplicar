package model;

import controller.*;
import java.sql.Connection;
import java.util.ArrayList;

public class LoginSignup {
    public void signupVolunteer(String sql, ArrayList values)throws Exception {

        Connection con = GetConnection.makeConnection();
        PutData pd = new PutData();
        pd.store(con, sql, values);

        con.close();
    }

}


