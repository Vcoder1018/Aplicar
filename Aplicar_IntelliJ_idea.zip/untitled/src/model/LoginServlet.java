package model;

import controller.PutData;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginServlet extends HttpServlet {
    public static String s = "d-none";
    public static String msg = "";
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session=req.getSession();
        Connection con = (Connection)session.getAttribute("connection");
        String email = req.getParameter("login_email");
        String pass = req.getParameter("login_password");
        String sql = "";
        int roll = Integer.parseInt(req.getParameter("roll"));
        if(roll == 1){
            sql = "select * from volunteer where email = '" + email + "'";
        }else {
            sql = "select name, email, password from organization where email = '" + email + "'";
        }
            try {
                PutData pd = new PutData();
                ResultSet rs =pd.getData(con,sql);
                if(rs.next()){
                    if(rs.getString(2).equals(email) && rs.getString(3).equals(pass)){
                        String name = rs.getString(1);
                        String city = rs.getString(4);
                        String country = rs.getString(5);
                        String address = rs.getString(6);
                        String profile = rs.getString(7);
                        String online = rs.getString(8);
                        String score = rs.getString(9);


                        session.setAttribute("name", name);
                        session.setAttribute("email", email);
                        session.setAttribute("city", city);
                        session.setAttribute("country", country);
                        session.setAttribute("address", address);
                        session.setAttribute("profile", profile);
                        session.setAttribute("online", online);
                        session.setAttribute("score", score);
                        String updateSql = "UPDATE `aplicar`.`volunteer` SET `online` = '1' WHERE (`email` = '"+ email +"');";
                        PreparedStatement ps = con.prepareStatement(updateSql);
                        int i = ps.executeUpdate();
                        resp.sendRedirect("find-projects.jsp");

                    }else {
                        s = "";
                        msg = "Incorrect Password!";
                        resp.sendRedirect("login.jsp");
                    }
                }else {
                    s = "";
                    msg = "No such email found! " + email;
                    resp.sendRedirect("login.jsp");
                }
            }catch (Exception e){
                System.out.println(e);
            }
    }
}
