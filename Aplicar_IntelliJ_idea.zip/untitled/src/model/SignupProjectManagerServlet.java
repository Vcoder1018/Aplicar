package model;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class SignupProjectManagerServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int form = Integer.parseInt(req.getParameter("form_no"));
        HttpSession session = req.getSession();
        if (form == 0){
            session.setAttribute("org_name",req.getParameter("signup_orgs_organization_name"));
            session.setAttribute("org_email",req.getParameter("signup_orgs_organization_email"));
            session.setAttribute("org_pass",req.getParameter("signup_orgs_organization_password"));
        }else if (form == 1){
            session.setAttribute("org_url",req.getParameter("signup_orgs_1_web_site"));
            session.setAttribute("org_contact",req.getParameter("signup_orgs_1_contact_number"));
            session.setAttribute("org_city",req.getParameter("signup_orgs_1_city"));
            session.setAttribute("org_country",req.getParameter("signup_orgs_1_country"));
        }
    }
}
