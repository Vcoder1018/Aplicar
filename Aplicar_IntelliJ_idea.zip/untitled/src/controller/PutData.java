package controller;

import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class PutData{

    public void setData(ArrayList values, PreparedStatement ps)throws Exception{
        System.out.println(1);
        for (int i=0; i<values.size(); i++){
            if (values.get(i) instanceof Integer){
                ps.setInt(i+1,(int)values.get(i));
            }else if (values.get(i) instanceof String){
                ps.setString(i+1,values.get(i).toString());
            }else if (values.get(i) instanceof Boolean){
                ps.setBoolean(i+1,(boolean)values.get(i));
            }else if (!(values.get(i) instanceof String) && !(values.get(i) instanceof Number) && !(values.get(i) instanceof Character) && !(values.get(i) instanceof Boolean)){
                ps.setBlob(i+1,(Blob)values.get(i));
            }
        }
        System.out.println(2);


    }

    public int store(Connection con, String sql, ArrayList values)throws Exception{
        PutData pd = new PutData();
        PreparedStatement ps = con.prepareStatement(sql);
        pd.setData(values, ps);
        return ps.executeUpdate();
    }

    public int update(Connection con, String sql, ArrayList values)throws Exception{
        System.out.println(3);
        PutData pd = new PutData();
        System.out.println(4);
        PreparedStatement ps = con.prepareStatement(sql);
        System.out.println(5);
        pd.setData(values, ps);
        System.out.println(6);
        return ps.executeUpdate();

    }

    public ResultSet getData(Connection con, String sql)throws Exception{
        PreparedStatement ps = con.prepareStatement(sql);
        return ps.executeQuery();
    }

}
